// Bio Information
//==========================================================================
var bio = {
   "name": "Surya Praksh",
    "role": "Web Developer",
    "welcomeMessage": "Hai I'm a Web Developer!",
    "contacts": {
        "mobile": "+91-8366815902",
        "email": "hellobabai123@gmail.com",
        "github": "https://github.com",
        "twitter": "https://twitter.com/suryaprakashmat",
        "location": "Vera Bobbili"
    },
    "skills": [
        "HTML", "CSS", "Javascript", "C","C++"
    ],
    "biopic": "images/fry.jpg"
};




bio.display = function(){

    var formattedRole = HTMLheaderRole.replace("%data%", bio.role);
    $("#header").prepend(formattedRole);

    var formattedName = HTMLheaderName.replace("%data%", bio.name);
    $("#header").prepend(formattedName);

    var formattedMobile = HTMLmobile.replace(/%data%/g, bio.contacts.mobile);
    $("#topContacts").append(formattedMobile);

    var formattedEmail = HTMLemail.replace(/%data%/g, bio.contacts.email);
    $("#topContacts").append(formattedEmail);

    var formattedGithub = HTMLgithub.replace(/%data%/g, bio.contacts.github);
    $("#topContacts").append(formattedGithub);



    var formattedBioPic = HTMLbioPic.replace("%data%", bio.biopic);
    $("#header").append(formattedBioPic);

    var formattedWelcomeMessage = HTMLwelcomeMsg.replace("%data%", bio.welcomeMessage);
    $("#header").append(formattedWelcomeMessage);
    $("#header").append(HTMLskillsStart);
    bio.skills.forEach(function(skill,index) {
        var formattedSkill = HTMLskills.replace("%data%", bio.skills[index]);
        $("#skills").append(formattedSkill);
    });

    //footer contact info
    var formattedTwitter = HTMLtwitter.replace(/%data%/g, bio.contacts.twitter);
    $("#topContacts").append(formattedTwitter);

     formattedMobile = HTMLmobile.replace(/%data%/g, bio.contacts.mobile);
    $("#footerContacts").append(formattedMobile);

     formattedEmail = HTMLemail.replace(/%data%/g, bio.contacts.email);
    $("#footerContacts").append(formattedEmail);

     formattedGithub = HTMLgithub.replace(/%data%/g, bio.contacts.github);
    $("#footerContacts").append(formattedGithub);

    formattedTwitter = HTMLtwitter.replace(/%data%/g, bio.contacts.twitter);
    $("#footerContacts").append(formattedTwitter);
    };

// Work History
//==========================================================================

var work = {
    "jobs": [
        {
            "employer": "Vedhya Embeded Services",
            "title": "Web & ad designer",
            "datesWorked": "October 2015 - Jan 2016",
            "location": "Visakapatnam",
            "description": "Create & implement web hosted content management system to radically increase product quality, consistency & workflow throughout company.<br> Create & post high volume of web based ads."
        },
        {
            "employer": "K L University",
            "title": "HTML Lecturer",
            "datesWorked": "Jan 2016 - Oct 2016",
            "location": "Vaddeswaram",
            "description":"Effectively teach the Html Css and Java scripting subjects for the students come around there."
        },
        {
            "employer": "Vizag Steel Plant",
            "title": "Technician",
            "datesWorked": "Sept 2016 - Oct 2017",
            "location": "Visakapatnam",
            "description": "Develop, perform, & report Reliability Testing & Life Data Analysis procedures <br>Diagnose product failures to component level(Field & Engineerings units) <br>Create & Maintain Design Failure Mode & Effects Analysis (DFMEA) to improve quality of product"
        }
    ]
};

work.display = function(){
    work.jobs.forEach(function(job) {

    //for(var job in work.jobs){
        $("#workExperience").append(HTMLworkStart);

        var formattedEmployer= HTMLworkEmployer.replace("%data%", job.employer);

        var formattedJobTitle= HTMLworkTitle.replace("%data%",job.title);

        var formattedEmployerTitle = formattedEmployer + formattedJobTitle;

        $(".work-entry:last").append(formattedEmployerTitle);

        var formattedDates= HTMLworkDates.replace("%data%",job.datesWorked);
        $(".work-entry:last").append(formattedDates);

        var formattedLocation= HTMLworkLocation.replace("%data%", job.location);
        $(".work-entry:last").append(formattedLocation);

        var formattedDescription= HTMLworkDescription.replace("%data%", job.description);
        $(".work-entry:last").append(formattedDescription);

    });
};

// Projects
//==========================================================================

var projects = {
    "projects":[{
        "title": "SKIN Cancer Thermography",
        "datesWorked": "OCT 2016",
        "description" : "SKIN Cancer Thermography is a techinique to detect the meline pigment disorder with out taking the blood samples from patients Body.We detect the cancer by takking thermographical images and apply some image proccessing techiniques. ",
        "images":["https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSNBdMAglmrCKRyUxt6KEtY6E_1a6QddDv9wQ7ALytUWtEYlf2ytw"]
    },
    {
        "title": "HOME AUTOMATION",
        "datesWorked": "FEB 2017",
        "description" : "Home Automation is a product in which we control house hold 230v ac current to opperate fans,lights and electronic gadgets with a smart remote,mobile.",
        "images":["https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS3GPfkQNP3B1DUoUbsf-0xsY5FrLznoBKgCP9NwZaaAdrH0Cgg"]
    }
]};


projects.display = function(){
//    for(var project in projects.projects){
    projects.projects.forEach(function(project) {

        $("#projects").append(HTMLprojectStart);

        formattedProjectTitle= HTMLprojectTitle.replace("%data%",project.title);
            $(".project-entry:last").append(formattedProjectTitle);

        formattedProjectDates= HTMLprojectDates.replace("%data%",project.datesWorked);
            $(".project-entry:last").append(formattedProjectDates);

        if(project.images.length>0){

              //  for (var image in projects.projects[project].images)
              //project.images.forEach(function(image) {
                formattedProjectImage= HTMLprojectImage.replace("%data%",project.images);
            $(".project-entry:last").append(formattedProjectImage);

            }

        formattedProjectDescription= HTMLprojectDescription.replace("%data%",project.description);
            $(".project-entry:last").append(formattedProjectDescription);


        });
};

// Education
//==========================================================================

var education = {
    "schools": [
        {
            "name": "K L University,Vijayawada",
            "degree": "B.E/B.Tech",
            "location": "Vijayawada",
            "majors": [
                "Electronics and Communication"
            ],
            "datesAttended": "June 2013 - May 2017 "
        },
         {
            "name": "Sri Chaitanya Juniour College",
            "degree": "Intermediate",
            "location": "Visakapatnam",
            "majors": [
                "M.P.C"
            ],
            "datesAttended": "June 2010 - April 2013  "
        },
        {
            "name": "Abhyudaya High School",
            "degree": "Tenth Class",
            "location": "Bobbili",
            "majors": [
                "S.S.C"
            ],
            "datesAttended": "June 2006 - April 2010  "
        }
    ],
    "onlineCourses": [
        {
            "title": "Front-End Nanodegree",
            "school": "Udacity",
            "dates": "July 2017",
            "url": "https://www.udacity.com"
        }
    ]
};

education.display = function(){

    $("#education").append(HTMLschoolStart);

    education.schools.forEach(function(school){

        formattedSchoolName= HTMLschoolName.replace("%data%",school.name);
            $(".education-entry:last").append(formattedSchoolName);


        formattedSchoolDegree= HTMLschoolDegree.replace("%data%",school.degree);
            $(".education-entry:last").append(formattedSchoolDegree);



        formattedDates= HTMLschoolDates.replace("%data%",school.datesAttended);
            $(".education-entry:last").append(formattedDates);



        formattedSchoolLocation= HTMLschoolLocation.replace("%data%",school.location);
            $(".education-entry:last").append(formattedSchoolLocation);

        if(school.majors.length>0){

               // education.schools.forEach(function(major){

                    formattedSchoolMajor= HTMLschoolMajor.replace("%data%",school.majors);

                    $(".education-entry:last").append(formattedSchoolMajor);
                //}

        }



     });

$(".education-entry:last").append(HTMLonlineClasses);

    education.onlineCourses.forEach(function(course){


        formattedOnlineTitle= HTMLonlineTitle.replace("%data%",course.title);
                    $(".education-entry:last").append(formattedOnlineTitle);

        formattedOnlineSchool= HTMLonlineSchool.replace("%data%",course.school);
                    $(".education-entry:last").append(formattedOnlineSchool);

        formattedOnlineDates= HTMLonlineDates.replace("%data%",course.dates);
                    $(".education-entry:last").append(formattedOnlineDates);

        formattedOnlineUrl= HTMLonlineURL.replace("%data%",course.url);
                    $(".education-entry:last").append(formattedOnlineUrl);





    });


};



// Internationalize Name
//==========================================================================


// Capitalize all last name and ensure first letter in first name is capitalized
function inName(name){
    name = bio.name;
    name = name.trim().split(" ");
    console.log(name);
    name[1]= name[1].toUpperCase();
    name[0]= name[0].slice(0,1).toUpperCase()+ name[0].slice(1).toLowerCase();

    return name[0]+" "+name[1];


}

$("#main").append(internationalizeButton);


// Clicks (Analytics)
//==========================================================================

$(document).click(function(loc){
    var x = loc.pageX;
    var y = loc.pageY;

    logClicks(x, y);});

// Call functions
//==========================================================================

bio.display();
work.display();
projects.display();
education.display();

$("#mapDiv").append(googleMap);
